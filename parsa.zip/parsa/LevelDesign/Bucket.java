package LevelDesign;

public class Bucket {
    public int capacity = 5;
    public int duration = -1;
    public int maxDuration = 3;
    public Boolean full = true;
    public Bucket(int capacity, int duration) {
        this.capacity = capacity;
        this.duration = duration;
        this.maxDuration = 5;
        this.full = false;
    }
}
