package LevelDesign;

public class Cell {
    public int x;
    public int y;
    public int grass = 0;

    public Cell(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
