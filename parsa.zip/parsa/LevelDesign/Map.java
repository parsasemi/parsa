package LevelDesign;

public class Map {
    public int length = 6;
    public int height = 6;
    public Cell[][] map = new Cell[height][length];
    ////////// Tamam Khane ha 0 beshan.

}
