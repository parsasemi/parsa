package LevelDesign;

public class Task {
    public int timeObj = 10000;
    public int chickenObj = 10000;
    public int buffaloObj = 10000;
    public int turkeyObj = 10000;
    public int coinObj = 10000000;
    public int eggObj = 10000;
    public int flourObj = 10000;
    public int featherObj = 10000;
    public int milkObj = 10000;
    public int cmilkObj = 10000;
    public int breadObj = 10000;
    public int weaveObj = 10000;
    public int clothObj = 10000;
    public int iceCreamObj = 10000;

    public boolean coinCheck = false;
    public boolean chickenCheck = false;
    public boolean buffaloCheck = false;
    public boolean turkeyCheck = false;
    public boolean eggCheck = false;
    public boolean flourCheck = false;
    public boolean featherCheck = false;
    public boolean milkCheck = false;
    public boolean cmilkCheck = false;
    public boolean breadCheck = false;
    public boolean weaveCheck = false;
    public boolean clothCheck = false;
    public boolean iceCreamCheck = false;
    public boolean timeCheck = false;

    public int totalCoin = 0;
    public int eggCounter = 0;
    public int flourCounter = 0;
    public int featherCounter = 0;
    public int milkCounter = 0;
    public int cmilkCounter = 0;
    public int breadCounter = 0;
    public int weaveCounter = 0;
    public int clothCounter = 0;
    public int iceCreamCounter = 0;
}
