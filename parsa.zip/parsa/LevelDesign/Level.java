package LevelDesign;

import Animals.DomesticAnimals;
import Animals.SpecialAnimals;
import Animals.WildAnimals;

import java.util.ArrayList;

public class Level {
    public String playerName  = new String();
    public int levelNumber;
    public int passedTime = 0;
    public boolean levelEnd = false;
    public boolean levelStarted;
    public int coin;
    public ArrayList<Ingredient> ingredients = new ArrayList<>();
    public ArrayList<DomesticAnimals.Chicken> chickens = new ArrayList<>();
    public ArrayList<DomesticAnimals.Buffalo> buffalos = new ArrayList<>();
    public ArrayList<DomesticAnimals.Turkey> turkies = new ArrayList<>();
    public ArrayList<WildAnimals.Bear> bears = new ArrayList<>();
    public ArrayList<WildAnimals.Lion> lions = new ArrayList<>();
    public ArrayList<WildAnimals.Tiger> tigers = new ArrayList<>();
    public ArrayList<SpecialAnimals.Cat> cats = new ArrayList<>();
    public ArrayList<SpecialAnimals.Dog> dogs = new ArrayList<>();
    public Map map = new Map();
    public Bucket bucket = new Bucket(0 ,-1);
    public Factory.WeaveFactory weaveFactory  = new Factory.WeaveFactory();
    public Factory.MillFactory millFactory = new Factory.MillFactory();
    public Factory.MilkFactory milkFactory = new Factory.MilkFactory();
    public Factory.Bakery bakery = new Factory.Bakery();
    public Factory.SewingFactory sewingFactory = new Factory.SewingFactory();
    public Factory.IceFactory iceFactory =  new Factory.IceFactory();
    public Storage storage = new Storage();
    public MotorCycle motorCycle = new MotorCycle();

}
