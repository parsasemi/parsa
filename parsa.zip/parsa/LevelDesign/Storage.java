package LevelDesign;

import java.util.ArrayList;

public class Storage {
    public int capacity = 30;
    public ArrayList<String> names =new ArrayList<>();
    public ArrayList<Integer> quantities = new ArrayList<>();
}
