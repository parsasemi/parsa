package LevelDesign;

import java.util.ArrayList;

public class MotorCycle {
    int capacity;
    ArrayList<String> names =new ArrayList<>();
    ArrayList<Integer> quantities = new ArrayList<>();
}
