package LevelDesign;

import java.util.ArrayList;

public class MotorCycle {
    public int capacity =10;
    public int counter = -1;
    public int Max = 10;
    public int coin =0;
    public ArrayList<String> names =new ArrayList<>();
    public ArrayList<Integer> quantities = new ArrayList<>();
}
