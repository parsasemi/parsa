public class LoginUser {
    String username;
    String password;

    public LoginUser(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
