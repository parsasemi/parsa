package Graphics;

public class LoginUser {
    String username;
    String password;
    LoginUser(String username, String password){
        this.username = username;
        this.password = password;
    }
}
