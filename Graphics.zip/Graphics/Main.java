package Graphics;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main  extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("mainGame.fxml"));
//        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root));
//        primaryStage.setFullScreen(true);
//        primaryStage.show();
        primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    public static void main(String[] args) throws IOException {
        launch( args);
        /*Program.Manager manager = new Program.Manager();
        Program.InputProcessor inputProcessor = new Program.InputProcessor(manager);
        inputProcessor.run();*/
/*        manager.writeBasicLevel1Info();
        manager.writeBasicLevel2Info();
        manager.writeBasicLevel3Info();
        manager.writeBasicLevel4Info();
        manager.writeBasicLevel5Info();
        manager.writeBasicLevel6Info();
        manager.writeBasicLevel7Info();
        manager.writeBasicLevel8Info();*/



    }
}
