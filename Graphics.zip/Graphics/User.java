package Graphics;

import LevelDesign.Level;

import java.util.ArrayList;

public class User {
    ArrayList<Level> levels = new ArrayList<>();

}
