package Graphics;

import LevelDesign.Level;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class MapController {

    Stage stage;
    Scene scene;
    Parent root;
    String username;
    int levelNumber;

    @FXML
    Button level1;
    @FXML
    Button level2;
    @FXML
    Button level3;
    @FXML
    Button level4;
    @FXML
    Button level5;
    @FXML
    Button level6;
    @FXML
    Button level7;
    @FXML
    Button level8;



    public static final Manager manager = new Manager();
    public void switchToGameplay(ActionEvent actionEvent) throws IOException {
        Button button = (Button) actionEvent.getSource();
        levelNumber = Integer.parseInt(button.getText());

        FXMLLoader loader = new FXMLLoader(getClass().getResource("mainGame.fxml"));
        root = loader.load();
        GamePlay gamePlay = loader.getController();
        gamePlay.playerLevel = manager.levelReturner(levelNumber);


        }
    }

