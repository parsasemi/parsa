package Graphics;

import LevelDesign.Level;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable
{
    @FXML private Button Storage;
    @FXML private Button Bucket;
    Manager manager = new Manager();
    private Image image = new Image(getClass().getResourceAsStream("Grass.png"));
    Level level = new Level();
    @FXML
    private GridPane Map;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        for (int i=0; i <6; i++){
            for (int j=0; j<6; j++){
                Tile tile = new Tile(i,j);
                tile.grass.setOnMouseClicked(mouseEvent -> tile.grass.setImage(image));
                tile.grassLabel.setOnMouseClicked(mouseEvent -> {
                    tile.grass.setImage(image);
                });
                Bucket.setOnAction(actionEvent -> {
                    try {
                        manager.Well(level);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
                Map.add(tile, j,i);
            }
        }

    }

}

