package Graphics;

import LevelDesign.Level;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class GamePlay {
    Stage stage;
    Scene scene;
    Parent root;

    Level playerLevel;

    public void run(){

    }
}
